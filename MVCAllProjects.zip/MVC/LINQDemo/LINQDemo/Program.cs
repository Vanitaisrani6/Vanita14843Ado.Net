﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            #region Array-LInQ to Objects
            //int[] numberarray = { 2, 3, 4, 5, 6, 7, 8 };
            //int[] numberarray1 = { 2, 3, 4 };
            //Console.WriteLine("List of even numbers : ");
            //for (int i = 0; i < numberarray.Length; i++)
            //{

            //    if (numberarray[i] % 2 == 0)
            //        Console.Write(numberarray[i] + " ");
            //}
            //Console.WriteLine();

            //using LINQ even numbers
            //IEnumerable<int> evenData = from num in numberarray orderby num descending where num % 2 == 0 select num;
            //Console.WriteLine("EvenNumbers of array are: ");
            //foreach (int item in evenData)
            //{
            //    Console.WriteLine(item);
            //}

            //method sysntax means lamda(input param => expression

            //IEnumerable< int > evenData1 = numberarray.Where(num => num % 2 == 0);
            //Console.WriteLine("EvenNumbers of array using lambda: ");
            //foreach (int item in evenData1)
            //{
            //    Console.WriteLine(item);

            //}
            //using LINQ square
            //IEnumerable<int> SqData = from num in numberarray1 select num * num;
            //Console.WriteLine("Squares of numbers in array is");
            //foreach (int item in SqData)
            //{
            //    Console.WriteLine(item);
            //}


            //IEnumerable<int> SqData1 = numberarray1.OrderBy(n => n).Select(n => n * n);
            //Console.WriteLine("Squares of numbers in array using lambda is");
            //foreach (int item in SqData1)
            //{
            //    Console.WriteLine(item);
            //}
            //int multiply = 0;
            //Console.WriteLine("Square of each no");
            //for (int j = 0; j < numberarray.Length; j++)
            //{
            //    multiply *= numberarray[j];

            //    //Console.Write(numberarray[i] + " ");
            //    Console.Write("Square of each no" + multiply);

            //}
            //Console.WriteLine();
            #endregion


            #region Genric collection -linqtoObjects

            List<Employee> empList = new List<Employee>()
            {
                //object initializer
                new Employee { EmpName="bhavana",  Address="mumbai", Department="accounts", Salary=15000},
                new Employee { EmpName="vishal",  Address="pune", Department="sales", Salary=18000},
                new Employee { EmpName="kavita",  Address="mumbai", Department="sales", Salary=25000},
                new Employee { EmpName="amit",   Address="mumbai", Department="accounts", Salary=20000},
                new Employee { EmpName="hemant", Address="pune", Department="sales", Salary=27000},
                new Employee { EmpName="aarti", Address="pune", Department="accounts", Salary=30000},
                new Employee { EmpName="varsha", Address="mumbai", Department="accounts", Salary=15000}
            };


            //foreach (Employee item in empList)
            //{
            //    Console.WriteLine(item);
            //}

            //where
            //list all amp staying mumbai


            //execution: ----defered execution the query is executed in for each not in query when the control reached for each 
            // if i add one more recoard in emp list then after adding for each first it demand . advange if any changes are added it will return all the changes also.

            //Console.WriteLine("defered execution");
            IEnumerable<Employee> query1 = from e in empList where e.Address == "mumbai" select e;
            query1 = empList.Where(e => e.Address == "mumbai");


            //foreach (Employee item in query1)
            //{
            //    Console.WriteLine(item);
            //}


            Console.WriteLine("-------------------------------------------------------------------");

            empList.Add(new Employee { EmpName = "Vanita", Address = "mumbai", Department = "sales", Salary = 25000 });
            //foreach (Employee item in query1)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.WriteLine("-------------------------------------------------------------------");
            //Console.WriteLine("immediate execution it will not affect the changes");


            //---and immediate execution it will not affect the changes

            IEnumerable<Employee> query2 = (from e in empList where e.Address == "mumbai" select e).ToList();
            query2 = empList.Where(e => e.Address == "mumbai").ToList();


            //foreach (Employee item in query2)
            //{
            //    Console.WriteLine(item);
            //}


            Console.WriteLine("-------------------------------------------------------------------");

            empList.Add(new Employee { EmpName = "Vanita", Address = "mumbai", Department = "sales", Salary = 25000 });
            //foreach (Employee item in query2)
            //{
            //    Console.WriteLine(item);
            //}


            //Console.WriteLine("-------------------------------------------------------------------");
            //Console.WriteLine("execution of immediate methods");
            //immetiate execution methods for single recoard
            //search recoard of vishal
            //first method: if recoard found it will return if recoard not fount it will throw exception
            //FirstOrDefaultmethod: if recoard is not fount it will return null i.e default value null for the class
            //single(): it will return single recoard
            //SingleOrDefault: if recoard doesnt exist will will return null i.e default  method
            //differnce between single and first is Single can return only one match if more than one found it will return exception 
            Employee employee = (from e in empList where e.EmpName == "kavita1" select e).FirstOrDefault();

            //methodsyntax
            employee = empList.Where(e => e.EmpName == "kavita").Single();
            employee = empList.Single(e => e.EmpName == "kavita");

            //Console.WriteLine("search with return" + employee);

            //Console.WriteLine("-------------------------------------------------------------------");
            //Console.WriteLine("anonymous type ");

            // anonymous type implicity type local type variable 
            // var is a local variable
            //var cannot be used to declare instance or class level variable
            //var cannot be used as parameter to a method.
            // var cannot be used a return type of a method


            // anonymous call need to created if we want to details of specified(ename, job,salary)
            //  imp anonymous type is read only only get method cannot be changed

            var query4 = from e in empList select new { e.EmpName, job = e.Department, e.Salary };

            query4 = empList.Select(e => new { e.EmpName, job = e.Department, e.Salary }); // using lambda

            //foreach (var item in query4)
            //{
            //    Console.WriteLine(item.EmpName +" "+item.job +" "+item.Salary +" "+item.GetType().Name);
            //}



            // Console.WriteLine("Query to order employees by department");
            //IEnumerable<Employee> query5 = from e in empList orderby e.Department select e;
            //  query5 = empList.OrderBy(e => e.Department).ToList();

            // foreach (Employee item in query5)
            // { 
            //    Console.WriteLine(item);
            // }
            // Console.WriteLine("-------------------------------------------------------------------");





            // Console.WriteLine("query to list all emp sort on dept, within dept on salary h to l");


            // IEnumerable<Employee> query6 = from e in empList orderby e.Salary descending, e.Department select e;
            // query6=
            ////query6 = empList.Where(e => e.Department == "sales").OrderByDescending(e => e.Salary)

            // foreach (Employee item in query6)
            // {
            //     Console.WriteLine(item);
            // }



            //distint Deptname
            IEnumerable<string> query7 = (from e in empList select e.Department).Distinct();
            foreach (string item in query7)
            {
                Console.WriteLine(item);
            }



            var query8 = from e in empList group e by e.Department;
            query8 = empList.GroupBy(e => e.Department);


            foreach (var item in query8)
            {

                Console.WriteLine(item.Key);
                foreach (var subitem in item)
                {
                    Console.WriteLine("\t" + subitem.EmpName + " " + subitem.Address + " " + subitem.Salary);

                }

            }


            IEnumerable<Employee> query9 = (from e in empList orderby e.Salary descending select e).Take(2);

            foreach (Employee item in query9)
            {
                Console.WriteLine(item);

            }


            var query10 = from e in empList
                          let bonus = e.Salary * 0.1m
                          where bonus > 2500
                          orderby bonus
                          select new { e.EmpName, e.Salary, bonus };

            foreach (var item in query10)
            {

                Console.WriteLine(item.EmpName + " " + item.Salary + " " + item.bonus);
            }

            //aggregate functions
            //total salary of  all emp

            decimal totalSalary = (from e in empList select e).Sum(e => e.Salary);

            Console.WriteLine("total Salary " + totalSalary);


            decimal MinSalary = (from e in empList select e).Min(e => e.Salary);
            Console.WriteLine("Min Salary " + MinSalary);

            decimal MaxSalary = (from e in empList select e).Max(e => e.Salary);
            Console.WriteLine("Max Salary " + MaxSalary);

            decimal AvgSalary = (from e in empList select e).Average(e => e.Salary);
            Console.WriteLine("Avg Salary " + AvgSalary);

            Console.WriteLine("--------------------------------------------------------------");
            var query11 = from e in empList
                          group e by e.Department into empgrp
                          select new { dept = empgrp.Key, salsum = empgrp.Sum(e => e.Salary) };


            foreach (var item in query11)
            {

                Console.WriteLine(item.dept + " " + item.salsum);
            }
            var query13 = empList.GroupBy(e => e.Department).Select(e => new { dept = e.Key, salsum = e.Sum(e => e.Salary) });

            foreach (var item in query13)
            {

                Console.WriteLine(item.dept + " " + item.salsum);
            }



           // var query14 = from emp in empList.GroupBy(emp => new { emp.Department, emp.Address }).OrderBy(grp => grp.Key.Department);
            var query14 = empList.GroupBy(emp => new { emp.Department, emp.Address }).OrderBy(grp => grp.Key.Department);

            foreach (var item in query14)
            {
                Console.WriteLine("\n");
                Console.WriteLine(item.Key.Department + " " + item.Key.Address + "total Employee" + item.Count().ToString()) ;
                foreach (var e in item)
                {
                    Console.WriteLine("\t" + e.ToString());
                }
            
            }


            #endregion

        }
    }
}
