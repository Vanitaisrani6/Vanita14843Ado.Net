﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program2
    {
        //static void Main(string[] args)
        //{

        //    string ans = "Y";
        //    do {
        //        Console.WriteLine("Enter Integer");
        //        int num=int.Parse(Console.Read)
        //    }
        //}
        //static string OddEvenCheck(int number)
        //{
        //    //string msg = "";
        //    //if (number %= 2 == 0)
        //    //{
        //    //    msg = Console.WriteLine("{0} is an even integer.\n", number);
        //    //}
        //    //else {
        //    //    msg = Console.WriteLine("{0} is an odd integer.\n", number);

        //    //}

        //    return msg;
        //}
    }
}
