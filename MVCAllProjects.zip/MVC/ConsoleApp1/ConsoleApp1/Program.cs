﻿using System;
using System.Drawing;

namespace ConsoleApp1
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    #region basic oddeven example
        //    //int num, rem;

        //    //Console.WriteLine("Check whether a number is even or odd :\n");

        //    //Console.WriteLine("Input an integer : ");
        //    //num = Convert.ToInt32(Console.ReadLine());
        //    // rem = num % 2;
        //    //if (rem == 0)
        //    //    Console.WriteLine("{0} is an even integer.\n", num);
        //    //else
        //    //    Console.WriteLine("{0} is an odd integer.\n", num);

        //    ////OddEvenCheck(num);

        //    //Console.WriteLine("Input an integer : ");
        //    //int number = Convert.ToInt32(Console.ReadLine());

        //    #endregion


           

        //    //int M = 5;
        //    //Console.WriteLine("For Month number: " + M);
        //    //findSeason(M);

        //    //M = 10;
        //    //Console.WriteLine("For Month number: " + M);
        //    //findSeason(M);
        //}
        public static void findSeason(int M)
        {

            
            switch (M)
            {
                case 12:
                case 1:
                case 2:
                    Console.WriteLine("WINTER");
                    break;
                case 3:
                case 4:
                case 5:
                    Console.WriteLine("SPRING");
                    break;
                case 6:
                case 7:
                case 8:
                    Console.WriteLine("SUMMER");
                    break;
                case 9:
                case 10:
                case 11:
                    Console.WriteLine("AUTUMN");
                    break;
                default:
                    Console.WriteLine("Invalid Month number");
                    break;
            }
        }



            //static string OddEvenCheck(int num)
            //{
            //    //int rem = num % 2;
            //    //if (rem == 0)
            //    // Console.WriteLine("{0} is an even integer.\n", num);
            //    //else
            //    //    Console.WriteLine("{0} is an odd integer.\n", num);
            //    //return num;

            //}

        }
}

