﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Oops
{
    class Rectangle
    {

      int length, width;

        public int Length
        {
            get { return length; }
            set { length= value; }
        }
        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        int GetArea()
        {
            return length * width;
        }
       public static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.Length = 10;
            rectangle.Width = 2;
            //rectangle.length = 10;
            //rectangle.width = 10;
            Console.WriteLine("Area of rectangle  =" + rectangle.GetArea());

        }
    }
}
