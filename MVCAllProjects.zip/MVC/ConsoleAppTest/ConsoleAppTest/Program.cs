﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace ConsoleAppTest
//{
//    class Program
//    {
//        enum Level
//        {
//            Low,
//            Medium,
//            High
//        };
//        static void Main(string[] args)
//        {



//            Level m = Level.High;
//            switch (m)
//            {
//                case Level.High:
//                    Console.WriteLine(Level.High);
//                    break;
//            }


//        }


//    }
//}
      

      
    

