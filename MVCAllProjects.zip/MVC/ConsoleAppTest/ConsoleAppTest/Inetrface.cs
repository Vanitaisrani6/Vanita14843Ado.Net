﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTest
{
    public class Inetrface
    {

        public abstract class B
        {
            public abstract void MethodA();
        }
        public interface IA
        {
            void MethodA();

        }
        public class C : B, IA
        {
            public void MethodA()
            {
                Console.WriteLine("A -1");

            }
            public override void MethodA()
            {
                Console.WriteLine("A -2");
            }

            static void Main(string[] args)
            {

                IA _ia = new C();
                _ia.MethodA();
            }

        }
    }
}
