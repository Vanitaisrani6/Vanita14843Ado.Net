﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Models
{
    public class OperationService : ITransientsService, IScopedService, ISingletonService
    {
        Guid id;

        public OperationService()
        {
            id = Guid.NewGuid();
        
        }

        public Guid GetOperationID()
        {

            return id;
        }

    }
}
