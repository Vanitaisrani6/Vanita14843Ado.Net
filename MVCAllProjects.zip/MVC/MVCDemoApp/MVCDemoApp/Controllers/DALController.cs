﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccessLayerLibrary;
using Microsoft.Extensions.Configuration;

namespace MVCDemoApp.Controllers
{
    public class DALController : Controller
    {
        EmpDataStore datastore = null;

        public IConfiguration Configuration { get; }

        public DALController(IConfiguration config,EmpDataStore empDataStore) {

            Configuration = config;
            datastore = empDataStore;
            string connstr = Configuration["ConnectionStrings:MyDBConnection"];
            datastore.SetConnection(connstr);
        }


        public IActionResult Index()
        {
            List<Emp> empList = datastore.GetAllEmps();
            return View(empList);
        }
    }
}
