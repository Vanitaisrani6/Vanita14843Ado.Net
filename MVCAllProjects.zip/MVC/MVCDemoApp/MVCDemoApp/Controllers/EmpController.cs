﻿using Microsoft.AspNetCore.Mvc;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Controllers
{
    public class EmpController : Controller
    {
        trainingContext db;


        public EmpController(trainingContext context)
        {
            db = context;

        }
        public IActionResult Index()
        {
            return View(db.Emps.ToList());
        }
        public IActionResult Details(int id)
        {
            //write linq query to search for emp record by id

            Emp emp = db.Emps.SingleOrDefault(e => e.Empno == id);
            if (emp == null)
            {
                return NotFound();
            }
            return View(emp);
        }

        [HttpGet]

        public IActionResult Create()
        {

            return View(new Emp());
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Emp emp)
        {   if (ModelState.IsValid)
                {
                db.Emps.Add(emp);
                db.SaveChanges();
                return RedirectToAction("Index");
            
            }
            return View(emp);

        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            //write linq query to search for emp record by id

            Emp emp = db.Emps.SingleOrDefault(e => e.Empno == id);
            if (emp == null)
            {
                return NotFound();
            }
            return View(emp);
        }

        [HttpPost]
        public IActionResult Edit(Emp emp)
        {
            if (!db.Emps.Any(e => e.Empno == emp.Empno))
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                db.Update(emp);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(emp);
        
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            //write linq query to search for emp record by id
            Emp emp = db.Emps.SingleOrDefault(e => e.Empno == id);
            if (emp == null)
            {
                return NotFound();
            }
            return View(emp);
        }

        ////[HttpPost]
        //public IActionResult Delete(Emp emp)
        //{
        //    if (!db.Emps.Any(e => e.Empno == emp.Empno))
        //    {
        //        return NotFound();
        //    }
        //    if (ModelState.IsValid)
        //    {
        //        db.Remove(emp);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(emp);

        //}

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            if (id > 0)
            {
                Emp searchemp = db.Emps.SingleOrDefault(e => e.Empno == id);
                if (searchemp != null)
                {
                    db.Emps.Remove(searchemp);
                    db.SaveChanges();
                    return RedirectToAction("Index");

                }

            }
            return View();
        }



    }
}
