﻿using Microsoft.AspNetCore.Mvc;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Controllers
{
    public class ServiceDemoController : Controller
    {
        private readonly ITransientsService _transientsService1, _transientsService2;
        private readonly IScopedService _scopedService1, _scopedService2;
        private readonly ISingletonService _singletonService1, _singletonService2;

        public ServiceDemoController(
            ITransientsService transientsService1,
           ITransientsService transientsService2,
           IScopedService scopedService1,
           IScopedService scopedService2,
           ISingletonService singletonService1,
           ISingletonService singletonService2
           )

        {

            _transientsService1 = transientsService1;
            _transientsService2 = transientsService2;

            _scopedService1 = scopedService1;
            _scopedService2 = scopedService2;

            _singletonService1 = singletonService1;
            _singletonService2 = singletonService2;
        }
        public IActionResult Index()
        {
            ViewBag.transient1 = _transientsService1.GetOperationID().ToString(); //request2
            ViewBag.transient2 = _transientsService2.GetOperationID().ToString(); //request2

            ViewBag.scoped1 = _scopedService1.GetOperationID().ToString();
            ViewBag.scoped2 = _scopedService2.GetOperationID().ToString();

            ViewBag.singleton1 = _singletonService1.GetOperationID().ToString();
            ViewBag.singleton2 = _singletonService2.GetOperationID().ToString();

            return View();

        }

       
    }
}
