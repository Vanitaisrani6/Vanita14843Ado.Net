﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }


        [Route ("Home/Greet/{name?}")]
        public IActionResult Greet(string name)
        {
            // return Content("Welcome to vanita app");

            ViewBag.wish = "Hello " + name;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult GetData(int id)
        {
            ViewBag.message = "Id=" + id;
            return View();
        }

   
        // [Route("Home/Addition/{​​​​​​​number1:int?}​​​​​​​/{​​​​​​​number2:int:range(1,7)?}​​​​​​​")]
        //[HttpPost("Home/Addition/{​​​​​​​number1:int?}​​​​​​​/{​​​​​​​number2:int:range(1,7)?}​​​​​​​")]
       // [Route("[controller]/[action]/{​​​​​​​number1:int?}​​​​​​​/{​​​​​​​number2:int:range(1,7)?}​​​​​​​")]

        public IActionResult Addition(int number1, int number2)
        {

           ViewBag.result ="Addition Result =" + (number1 + number2);
            return View();
        }

        public IActionResult ModelDemo()
        {
            Employee employee = new Employee { EmpId = 14843, EmpName = "Vanita Israni", Salary = 250000 };
           // ViewBag.emp = employee;
           // return View();

            ViewData["emp"] = employee;
            return View();

        }

        public IActionResult EmployeeForm()
        {
            return View(new Employee());
        
        }

        public IActionResult DisplayEmployeeData(Employee employee)

        {

            if (ModelState.IsValid)
            {
                return View(employee);

            }
            return View("EmployeeForm", employee);            
        }



       




    }
}
