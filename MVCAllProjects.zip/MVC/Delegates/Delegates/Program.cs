﻿using System;

namespace Delegates
{

    //create Delgate
    //return methodname([paramerters])


    delegate int CalculateDelegate(int number1, int number2);
    class Program
    {


        static void Main(string[] args)
        {
            //3 instance of delegate point to method
            //CalculateDelegate delegateObj = new CalculateDelegate(Addition);
            CalculateDelegate delegateObj = Addition;


            //4 invoke delegate
            int result = delegateObj(10, 3);
            Console.WriteLine("Addition  =" + result);


            //anonymous method

            CalculateDelegate delegateObj2 = delegate (int a, int b)
              {
                  return a * b;
  
              };


            int result1 = delegateObj2(7, 2);
            Console.WriteLine("Multiplication " + result1);


            CalculateDelegate delegateObj3 = (first, second) => first - second;
            result = delegateObj3(10, 5);
            Console.WriteLine("Subtraction = " + result);
        }

        //2. method
        static int Addition(int x, int y)
        {
            return x + y;
         }
    }
}
