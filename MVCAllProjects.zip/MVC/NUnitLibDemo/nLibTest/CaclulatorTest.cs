﻿using NUnit.Framework;
using System;
using NUnitLib;

namespace nLibTest
{
    public class CaclulatorTest

    {
        calculator calculator;
        //setup method will run before every test method
        [SetUp]
        public void Init()
        {
            calculator = new calculator();
        }



        //TearDown method will run after completing every test method
        public void Cleanup()
        {
            calculator = null;
        }



      // // [Test]


      //  public void Test_Addition_with_Valid_Integers()
      //  {
      //     // calculator calculator = new calculator();
      //      int result = calculator.Addition(5, 3);



      //      //Assert.AreEqual(expected, actual)
      //      Assert.AreEqual(8, result);
      //  }

      // // [Test]
      //  public void Test_Addition_with_Valid_Negative_Integers()
      //  {
      //     // calculator calculator = new calculator();
      //      int result = calculator.Addition(-5, -3);



      //      //Assert.AreEqual(expected, actual)
      //      Assert.AreEqual(-8, result);
      //  }
      // // [Ignore("Ignore Tese")]

      //  public void Test_Ignore()
      //  {


      //  }

      ////  [Test]
      //  public void Test_subtract_arguments_Exception()
      //  {
      //     // calculator calculator = new calculator();
      //      Assert.Catch<DivideByZeroException>(() => calculator.Subtraction(3, 5));
      //    //  Assert.Throws<DivideByZeroException>(() => calculator.Subtraction(3, 5));

      //  }
      // // [TestCase(1, 2, 3)]
      // // [TestCase(-1, -2, -3)]
      // // [TestCase(3, -5, -2)]
      // // [TestCase(-5, 3, -2)]
      // // [TestCase(0, 0, 0)]


        //[Test]
        //public void Test_Addition_Multiple(int first, int second, int expectedresult)
        //{
        //    //calculator calculator = new calculator();
        //    int result = calculator.Addition(first, second);
        //    Assert.AreEqual(expectedresult, result);
        //}

        [Test]
        public void Test_Divison_with_Valid_Integers()
        {
            // calculator calculator = new calculator();
            int result = calculator.Division(6, 2);



            //Assert.AreEqual(expected, actual)
            Assert.AreEqual(3, result);
        }
        [Test]
        public void Test_Divide_By_Zero_Exception()
        {
            // calculator calculator = new calculator();
            Assert.Catch<DivideByZeroException>(() => calculator.Division(3, 0));
            //  Assert.Throws<DivideByZeroException>(() => calculator.Subtraction(3, 5));

        }
        [Test]
        public void Test_Argument_Exception()
        {
            // calculator calculator = new calculator();
            Assert.Catch<ArgumentException>(() => calculator.Division(3, -5));
            //  Assert.Throws<DivideByZeroException>(() => calculator.Subtraction(3, 5));

        }





    }
}
