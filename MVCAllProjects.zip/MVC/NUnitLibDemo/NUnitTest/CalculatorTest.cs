﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnitLib;

namespace NUnitTest
{
    public class Class1
    {
           [Test]
            public void Test_Addition_with_Valid_Integers()
            {
                calculator calculator = new calculator();
                int result = calculator.Addition(5, 3);



                //Assert.AreEqual(expected, actual)
                Assert.AreEqual(8, result);
            }



        
    }
}
