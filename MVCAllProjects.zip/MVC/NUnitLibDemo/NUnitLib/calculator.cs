﻿using System;

namespace NUnitLib
{
    public  class calculator
    {
        public int Addition(int first, int second)
        {
            return first + second;
        }



        public int Subtraction(int first, int second)
        {
            if (first < second)
            {
                throw new ArgumentException($"First number {first} is less then the second number {second}");



            }
            return first - second;
        }



        public int Division(int first, int second)
        {
            if (first == 0)

            {
                throw new DivideByZeroException($"First no {first} cannot be zero");
            }
            else if (second< 0)
            {
                throw new ArgumentException($"Second no {second} is negative");

            }
            else
            {
                return first / second;
            }
        }
    }
}
