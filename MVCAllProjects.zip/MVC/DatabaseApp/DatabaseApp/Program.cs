﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace DatabaseApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Disconnected_Dept();
            //Connect_Emp();
            //Console.WriteLine(Validate_User("vanita", "happyvani123"));
        }

        static void Disconnected_Dept()
        {
            //SqlConnection connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB; initial catalog=Training; Integrated Security=True;");


            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB; database=Training; Integrated Security=True;");

            string query = "select * from Dept";
            SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
            DataSet ds = new DataSet();

            adapter.Fill(ds, "dept");


            //display when you have collections of objects use for each loop
            foreach (DataRow row in ds.Tables["dept"].Rows)
            {

                Console.WriteLine(row["DeptNo"] + "\t" + row["dname"] + "\t" + row["loc"]);
            }

        }


        static void Connect_Emp()
        {
            SqlConnection connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB; database=Training; Integrated Security=True;");
            string sql = "Select* from emp";
            SqlCommand command = new SqlCommand(sql, connection);
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {

                Console.WriteLine(reader["EmpNo"] + " \t " + reader["Ename"]);

            }

            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }



        }

        static string Validate_User(string username,string password)
        {

            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(@"server=(localdb)\MSSQLLocalDB; database=Training; Integrated Security=True;");
                string sql = "Select * from userdata where username=@uname and password=@pwd";
                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("uname", username);
                command.Parameters.AddWithValue("pwd", password);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                    return "valid User";

                }
                else {
                    return "Invalid username and password";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }



        }
    }
}
