﻿using System;
using EFCoreDemo.Models;
using System.Collections.Generic;
using System.Linq;

namespace EFCoreDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            TrainingContext db = new TrainingContext();
            IEnumerable<Emp> empData = db.Emps.ToList();
            Console.WriteLine("List of all Employees from Emp table");
            foreach (Emp item in empData)
            {
                Console.WriteLine(item.Empno + " " + item.Ename + " " + item.Job + " " + item.Sal + " " + item.Deptno);

            }


            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("List all emps as per the job");
            //list all emps as per the job
            IEnumerable<Emp> empjob = db.Emps.OrderBy(e => e.Job);

            foreach (Emp item in empjob)
            {
                Console.WriteLine(item.Ename + " " + item.Job); ;
            }

            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("Total Salary of all employees");
            //print total sal
            var sumSal = db.Emps.Sum(e => e.Sal);

            Console.WriteLine("Total Salary of all emps=" +sumSal);


            //print total sal for each dept
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("Total Salary by each dept");
            var query2 = db.Emps.GroupBy(e => e.Deptno).Select(e => new
            {
                dept = e.Key,
                salsum = e.Sum(e => e.Sal)
            });
            foreach (var item in query2)
            {
                Console.WriteLine(item.dept + " " + item.salsum);
            }


            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("list dept and emps for that dept");
            // list dept and emps for that dept
            //10
            //....
            //....
            //20
            //....
            //....
            var query3 = from e in db.Emps.AsEnumerable() group e by e.Deptno;
            foreach (var item in query3)
            {
                Console.WriteLine(item.Key);
                foreach (var row in item)
                {
                    Console.WriteLine(row.Ename + " " + row.Job);
                }
            }

            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("Output of Inner Join");
            var joinData = from e in db.Emps
                           join d in db.Depts
            on e.Deptno equals d.Deptno
                           select new { EmpName = e.Ename, e.Job, e.Sal, DeptName = d.Dname };
            foreach (var item in joinData)
            {
                Console.WriteLine(item.EmpName + " " + item.Job + " " + item.Sal + " " + item.DeptName);
            }

            var joindata1 = db.Emps.Join(db.Depts, e => e.Deptno, d => d.Deptno, (e, d) => new { e.Ename, d.Dname });


            //left outer join
            //king
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("Output of left outer join");
            var joinData2 = from e in db.Emps
                            join d in db.Depts
                            on e.Deptno equals d.Deptno
                            into empdept
                            from d in empdept.DefaultIfEmpty()
                            select new { e.Ename ,d.Dname };

            foreach (var item in joinData2)
            {
                Console.WriteLine(item.Ename +"  "+item.Dname);
            }






        }
    }
}
