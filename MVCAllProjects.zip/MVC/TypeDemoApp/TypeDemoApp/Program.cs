﻿using System;

namespace TypeDemoApp
{

    struct Employee
    {
        public int EmpId;
        public string EmpName;
        public double Salary;

        public override string ToString()
        {
            return string.Format($"EmdId {EmpId} EmpName: { EmpName} Salary: { Salary}");
        }

        public Employee(int eid,string ename, double salary)
        {
            EmpId = eid;
            EmpName = ename;
            Salary = salary;

        }
    }


    enum Gender
    { 
    male=1,female,transgender,other
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee(14843, "Vanita Israni", 270000);
            Console.WriteLine(employee);
            Console.WriteLine(DayOfWeek.Monday+ "--" +(int) DayOfWeek.Monday);

            Console.WriteLine(DayOfWeek.Sunday + "--" + (int)DayOfWeek.Sunday);


            Console.WriteLine(Gender.female + "--" + (int)Gender.female);
        }
    }
}
