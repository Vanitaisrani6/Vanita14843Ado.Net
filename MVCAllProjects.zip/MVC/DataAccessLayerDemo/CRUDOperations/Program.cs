﻿using System;
using System.Collections.Generic;
using DataAccessLayerLibrary;

namespace CRUDOperations
{
   public class Program
    {
        static void Main(string[] args)
        {


            Program program = new Program();



            // program.InsertEmp();

            Console.WriteLine("-------------------------------------------------------------------");
            program.DisplayAllEmp();
            Console.WriteLine("-----------------------------------------------------------------------------------");
            /// Console.WriteLine("Enter the Emp no to display Information");
            //int empno = Convert.ToInt32(Console.ReadLine());
            //program.DisplayEmpByNo(empno);
            //program.RemoveEmpByNo();
            program.UpdateEmp();
        }
        
        EmpDataStore empDataStore;

        public Program()
        {
            empDataStore = new EmpDataStore(@"server=(localdb)\MSSQLLocalDB; database=Training ; Integrated Security= True;");
        }
        void DisplayAllEmp()
        {
            List <Emp> empList = empDataStore.GetAllEmps();
            foreach (Emp item in empList)
            {
                Console.WriteLine(item);
            }
        }


        void DisplayEmpByNo(int empno)
        {
            Emp emp =empDataStore.GetEmpByNo(empno);
            if (emp != null)
            {
                Console.WriteLine(emp);

              }
            else
            {
                Console.WriteLine($"Employee no.{empno} not found");
            }
         
        }

        void InsertEmp()

        {

            Console.WriteLine("Enter Empno");
            int empno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            string empname = Console.ReadLine();
            Console.WriteLine("Enter DateTime");
            DateTime hdate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Salary");
            decimal salary = Convert.ToDecimal(Console.ReadLine());

            try {

                Emp newEmp = new Emp
                {
                    EmpNo=empno, EmpName=empname,HireDate=hdate,Salary=salary

                };

                int result = empDataStore.AddEmp(newEmp);
                if (result == 1)
                {
                    Console.WriteLine("Records Inserted Successfully");

                }
                else {

                    Console.WriteLine("Not Inserted");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception" + ex.Message);
            
            }

        }


        void RemoveEmpByNo()
        {
            Console.WriteLine("Enter Empno");
            int empno = Convert.ToInt32(Console.ReadLine());
            try
            {

            

                int result = empDataStore.RemoveEmpbyNo(empno);
                if (result == 1)
                {
                    Console.WriteLine("Records Deleted Successfully");

                }
                else
                {

                    Console.WriteLine("Not Removed");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception" + ex.Message);

            }

        }



        void UpdateEmp()

        {

            Console.WriteLine("Enter Empno");
            int empno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            string empname = Console.ReadLine();
            Console.WriteLine("Enter DateTime");
            DateTime hdate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Salary");
            decimal salary = Convert.ToDecimal(Console.ReadLine());

            try
            {

                Emp newEmp = new Emp
                {
                    EmpNo = empno,
                    EmpName = empname,
                    HireDate = hdate,
                    Salary = salary

                };

                int result = empDataStore.ModifyEmp(newEmp);
                if (result == 1)
                {
                    Console.WriteLine("Records Updated Successfully");

                }
                else
                {

                    Console.WriteLine("Not Updated");
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception" + ex.Message);

            }

        }




    }
}
