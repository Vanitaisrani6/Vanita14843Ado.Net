﻿using System;

namespace DataAccessLayerLibrary
{
    public class Emp
    {
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public Nullable <DateTime> HireDate { get; set; }
        public Nullable <decimal> Salary { get; set; }

        public override string ToString ()
            {
            return string.Format($"Empno={EmpNo} EmpName={EmpName} HireDate={ HireDate} Salary={ Salary}");
            }

    }
}
