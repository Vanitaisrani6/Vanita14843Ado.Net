﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace DataAccessLayerLibrary
{
    public class EmpDataStore
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;



        public EmpDataStore() { }
        public EmpDataStore(string connenctionstring)
        {
            connection = new SqlConnection(connenctionstring);
        }

         public void SetConnection(string connectionstring)
        {

            connection = new SqlConnection(connectionstring);
        }
        //getAllEmps -return all emps data from table
        public List<Emp> GetAllEmps()
        {
            try {
                string sql = "select * from emp";
                command = new SqlCommand(sql, connection);
                if(connection.State == ConnectionState.Closed)
                    {
                    connection.Open();                    
                }
                reader = command.ExecuteReader();
                List<Emp> EmpList = new List<Emp>();
                while (reader.Read())
                {
                    Emp emp = new Emp();
                    emp.EmpNo = (int)reader["EmpNo"];
                    emp.EmpName = reader["Ename"].ToString();
                    emp.HireDate = reader["HireDate"] as DateTime?;
                    emp.Salary =  reader["Sal"] as decimal?;

                    EmpList.Add(emp);
                }

                return EmpList;


            }
            catch (SqlException)

            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }


        public Emp GetEmpByNo(int empno)
        {

            try
            {
                string sql = "select * from emp where empno =@empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empno);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                reader = command.ExecuteReader();
                Emp emp = null;
                if (reader.Read())
                {
                    emp = new Emp();
                    emp.EmpNo = (int)reader["EmpNo"];
                    emp.EmpName = reader["Ename"].ToString();
                    emp.HireDate = reader["HireDate"] as DateTime?;
                    emp.Salary = reader["Sal"] as decimal?;
                    
                }

                return emp;


            }
            catch (SqlException)

            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }


        public int AddEmp(Emp empObj)
        {

                try
                {
                    string sql = "Insert into Emp(Empno,ename,hiredate,sal) values(@empno,@empname,@hiredate,@salary)";
                    command = new SqlCommand(sql, connection);
                    command.Parameters.AddWithValue("empno", empObj.EmpNo);
                    command.Parameters.AddWithValue("empname", empObj.EmpName);
                    command.Parameters.AddWithValue("hiredate", empObj.HireDate);
                    command.Parameters.AddWithValue("salary", empObj.Salary);
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    int count = command.ExecuteNonQuery();
                    return count;
                }
                catch (SqlException)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }

            }

        public int RemoveEmpbyNo(int empno)
        {
            try
            {
                string sql = "Delete from emp where empno =@empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empno);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                int count = command.ExecuteNonQuery();
                return count;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }


        public int ModifyEmp(Emp empObj)
        {

            try
            {
                string sql = "Update emp set ename=@empname,hiredate=@hiredate,sal=@salary where Empno=@empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empObj.EmpNo);
                command.Parameters.AddWithValue("empname", empObj.EmpName);
                command.Parameters.AddWithValue("hiredate", empObj.HireDate);
                command.Parameters.AddWithValue("salary", empObj.Salary);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                int count = command.ExecuteNonQuery();
                return count;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }





    }

}

