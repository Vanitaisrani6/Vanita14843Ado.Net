﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EFCodeFirstAssignment
{
    [Table("Review")]
    public class Review
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ReviewId { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string ReviewText { get; set; }

        [ForeignKey("BookId")]
        public Book Book { get; set; }

        [ForeignKey("MemberId")]
        public Member Member { get; set; }


    }
}
