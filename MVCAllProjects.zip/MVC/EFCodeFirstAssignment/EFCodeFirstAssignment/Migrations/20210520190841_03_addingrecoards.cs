﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFCodeFirstAssignment.Migrations
{
    public partial class _03_addingrecoards : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
