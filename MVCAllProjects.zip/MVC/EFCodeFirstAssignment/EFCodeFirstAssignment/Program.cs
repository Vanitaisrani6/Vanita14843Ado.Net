﻿using EFCodeFirstAssignment.Migrations;
using System;

namespace EFCodeFirstAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            SeedDataBase();
            BookDBContext db = new BookDBContext();

        }
        private static void SeedDataBase()
        {

            BookDBContext db = new BookDBContext();


            Publisher Publisher1 = new Publisher()
            {
                PublisherId = 201,
                PublisherName = "JohnStanley",
                Country = "France"


            };

            db.Publishers.Add(Publisher1);
            db.SaveChanges();


            Book Book1 = new Book()
            {
                BookId = 1,
                BookName = "HarryPotter",
                Publisher = Publisher1
            };

            db.Books.Add(Book1);
            db.SaveChanges();


            Member Member1 = new Member()
            {
                MemberId = 1001,
                MemberName = "VanitaIsrani"
               
            };

            db.Members.Add(Member1);
            db.SaveChanges();

            Review Review1 = new Review()
            {
                ReviewId = 101,
                ReviewText = "Harry Potter series 02 Book is very Amazing",
                Book = Book1,
                Member = Member1

            };

            db.Reviews.Add(Review1);
            db.SaveChanges();




        }
    }
}
