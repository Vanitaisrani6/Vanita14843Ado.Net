﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Validators
{
    class Validation
    {
        static void Main(string[] args)
        {

            Validation p = new Validation();
            Console.WriteLine("Enter name to check whether contains 5 char or not... ");
            string nameChar = Convert.ToString(Console.ReadLine());
            p.IsFiveChar(nameChar);



            Console.WriteLine("Enter name to check whether it contains digit or not... ");
            string str = Convert.ToString(Console.ReadLine());
            p.IsDigitOnly(str);



            Console.WriteLine("Enter name to check whether it contains uppercase letter or not ");
            var str1 = Convert.ToChar(Console.ReadLine());
            p.IsUpperCase(str1);
        }
        bool IsFiveChar(string str)
        {
            if (str.Length != 5) { return false; }
            return true;
        }

        bool IsDigitOnly(string str)
        {
            foreach (char c in str)
            {

                if (c < '0' || c > '9')
                    return false;
            }
            return true;
        }

        bool IsUpperCase(char str)
        {
            bool result = char.IsUpper(str);
            return result;
        
        }
    }
}
