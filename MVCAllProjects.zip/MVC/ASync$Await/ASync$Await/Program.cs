﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ASync_Await
{
    class Program
    {
        static void Main(string[] args)
        {
            Method();
            Console.WriteLine("Main Thread");
            Console.WriteLine();

            
        }
        public static async void Method()
        {
            await Task.Run(new Action(LongTask));
            Console.WriteLine("New Thread"); // action 
        
        }
        public static void LongTask()
        {

            Thread.Sleep(2000);
        }
    }
}
