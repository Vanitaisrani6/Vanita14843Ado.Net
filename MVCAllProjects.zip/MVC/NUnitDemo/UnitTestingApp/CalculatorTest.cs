﻿using System;
using NUnit.Framework;
using NUnitLin;

namespace UnitTestingApp
{
   public  class CalculatorTest
    {
        [Test]
        public void Test_Addition_with_Valid_Integers()
        {
            Calculator calculator = new Calculator();
            int result = calculator.Addition(5, 3);

            //Assert.AreEqual(expected, actual)
            Assert.AreEqual(8, result);
        }  
    }
}
