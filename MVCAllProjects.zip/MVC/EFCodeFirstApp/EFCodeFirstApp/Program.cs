﻿using System;
using System.Linq;

namespace EFCodeFirstApp
{
    class Program
    {
        static void Main(string[] args)
        {
           // SeedDataBase();

            EFCodeFirstDBContext db = new EFCodeFirstDBContext();
            //search recoard with product id=101

            Product product = db.Products.SingleOrDefault(p => p.ProductId == 101);

            //if (product != null)
            //{
            //    product.ProductName = "mobile";
            //    product.Price = 30000;

            //    db.SaveChanges();
            //    Console.WriteLine("Recoard Updated");
            //}
            //else {
            //    Console.WriteLine( "Not Found");
            //}


            //delete

            if (product != null)
            {
                db.Products.Remove(product);
                db.SaveChanges();
                Console.WriteLine("Recoard Deleted");
            }
            else
            {
                Console.WriteLine("Not Found");
            }


        }

        private static void SeedDataBase()
        {
            EFCodeFirstDBContext db = new EFCodeFirstDBContext();
            Category category1 = new Category()
            {
                CategoryId = 1,
                 CategoryName = "ELectronics"


            };

            db.Categories.Add(category1);
            db.SaveChanges();

            Product product1 = new Product()
            {

                ProductId = 101,
                ProductName = "Laptop",
                Category=category1,
                Price=10000
            };
            db.Products.Add(product1);
            db.SaveChanges();
        
        }
    }
}
