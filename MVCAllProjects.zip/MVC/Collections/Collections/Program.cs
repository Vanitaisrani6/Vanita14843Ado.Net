﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Array
            //int[] numArray = new int[3];
            //numArray[0] = 10;
            //numArray[1] = 20;
            //numArray[2] = 30;
            //for (int i = 0; i < numArray.Length; i++)
            //{
            //    Console.WriteLine("numArray ==" +numArray[i]);
            // }


            //int[] numArray1 = { 40, 70, 60, 10 };

            //Array.Sort(numArray1);
            //for (int i = 0; i < numArray1.Length; i++)
            //{
            //    Console.WriteLine("numArray1 ==" + numArray1[i]);
            //}
            #endregion

            #region Collections

            //ArrayList gender = new ArrayList();
            //gender.Add("Male");
            //gender.Add("Female");
            //gender.Add("Trasngender");
            //gender.Insert(2, "other");
            //gender.Add(20);
            //gender.Add(true);


            //// object instializer
            ////Person person = new Person() { FirstName = "Vanita", LastName = "Israni" };
            //gender.Add(new Person() { FirstName = "Vanita", LastName = "Israni" });//6

            //Console.WriteLine(((Person) gender[6]).FirstName);




            //for (int i = 0; i < gender.Count; i++)
            //{
            //    Console.WriteLine(i +"-- " +gender[i]);
            // }

            #endregion


            #region Generic

            //List<string> countryName = new List<string>();
            //countryName.Add("India");
            //countryName.Add("UK");
            //countryName.Add("US");

            //List<int> intCollection = new List<int>();
            //intCollection.Add(100);

            //List<Person> PersonList = new List<Person>();
            //PersonList.Add(new Person { FirstName = "Vanita", LastName = "Israni" });
            //Console.WriteLine(PersonList[0].FirstName);

            #endregion


            #region NullableTypes
            ////nullable type works with only value types(int,string,bool structs,float,double,decimal)

            ////int z = 10;
            ////z = null;

            //Nullable<int> x = null;
            //x = 100;
            ////x = null;

            //int? y = null;
            //y = 30;
            //y = null;


            ////(x:HasValue)?

            //if(x.HasValue)

            //{
            //    Console.WriteLine(x);
            //}
            //else {
            //    Console.WriteLine("x is null");
            //}

            //Console.WriteLine("Addition" + (x.GetValueOrDefault(0) +y.GetValueOrDefault(0)));
            #endregion


        }
    }
}
