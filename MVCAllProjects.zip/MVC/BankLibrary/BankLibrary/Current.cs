﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
  public sealed class Current :Bank
    {
        public sealed override void Withdraw(double amount)
        {
            throw new NotImplementedException();
        }

    }


}
