﻿using System;

namespace BankLibrary
{
    public abstract class Bank
    {
        #region Feilds and Properties
        private string accontHolderName;
        public string AccontHolderName
        {
            get{ return accontHolderName; }
            set {accontHolderName=value;}
        }
        double balance;

        //mixed access specfier for the property we can control get and set
        public double Balance
        {
            get { return balance; }
            protected set { balance = value; }
        }

        #endregion

        #region Methods
        public void Deposit(double amount)
        {
            Balance += amount;        
        }

        //public virtual void Withdraw(double amount)
        //{
        //    Balance -= amount;
        //}
        public abstract void Withdraw(double amount);


        public override string ToString()
        {
            return string.Format($"Account Holder Name={AccontHolderName},Balance={Balance}");
        }

        #endregion

        #region Constructor
        //static constructor
        // no parameter
        //will be run once the class is loadeed only
        //static Bank()
        //{
        //    Counter = 2000;
        //}
        public Bank()
        {
            Balance = 1000;
            Counter++;
        }

        public Bank(string name, double amount): this()
        {
            AccontHolderName = name;
            Balance = amount;
        }
        #endregion

        #region Static Member

        private static int counter;
        public static int Counter
        {
            get { return counter; }
            set { counter = value; }
        }

        #endregion
    }
}
