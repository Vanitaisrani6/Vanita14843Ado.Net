﻿using System;
using BankLibrary;
namespace HDFCAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            //#region Bank Objects
            //Bank bank = new Bank();
            //bank.AccontHolderName = "Vanita Israni";
            ////bank.Balance =20000;

            //Console.WriteLine(bank);
            //bank.Deposit(2000);
            //Console.WriteLine("After Deposit------------" + bank);

            //bank.Withdraw(1000);
            //Console.WriteLine("After Withdraw------------" + bank);


            //Bank bankb1 = new Bank("Vanita",10000);
            //Console.WriteLine(bankb1);

            //#endregion


            #region Saving Objects
            Savings savings = new Savings();
            savings.AccontHolderName = "Rohan";
            Console.WriteLine(savings);


            Savings savingss1 = new Savings("pooja",30000);

            Console.WriteLine(savingss1);
            try {
                savingss1.Withdraw(500000);
            }
            catch (BalanceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine(savingss1);
            #endregion


            #region Abstract
            Current current = new Current();
            current.Withdraw(0);
            #endregion
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Total no of objects created   " + Bank.Counter);
            
    }
    }
}
