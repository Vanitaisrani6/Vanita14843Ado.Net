﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVCDemoApp.Models
{
    public class Employee
    {

        [Required(ErrorMessage ="EmpId is compulsary feild")]
        [RegularExpression (@"[0-9]{4}", ErrorMessage ="Enter 4 digit EmpId")]
        public int? EmpId { get; set; }

        [Required (ErrorMessage ="Emp name is compulsary")]
        [StringLength(10,ErrorMessage ="Maximum EmpName length is 10 characters")]
        public string EmpName { get; set; }

        [Required(ErrorMessage = "Salary name is compulsary")]
        public double? Salary { get; set; }
    }
}
